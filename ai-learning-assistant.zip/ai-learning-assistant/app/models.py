from pydantic import BaseModel, EmailStr
from typing import List, Optional

class StudentRegistration(BaseModel):
    name: str
    email: EmailStr
    age: int
    current_education_level: str
    target_subjects: List[str]
    learning_goals: Optional[str] = None

class StudentProfileResponse(BaseModel):
    student_id: str
    status: str
    message: str
