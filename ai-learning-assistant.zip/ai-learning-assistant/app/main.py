from fastapi import FastAPI, HTTPException
from app.models import StudentRegistration, StudentProfileResponse
import uuid

app = FastAPI(title="AI Learning Assistant API")

# Mock database for MVP
fake_db = {}

@app.get("/")
def read_root():
    return {"message": "Welcome to the AI Learning Assistant API"}

@app.post("/api/register", response_model=StudentProfileResponse)
def register_student(student: StudentRegistration):
    # Check if user exists
    if any(s['email'] == student.email for s in fake_db.values()):
        raise HTTPException(status_code=400, detail="Email already registered")
    
    # Generate unique ID and save
    student_id = str(uuid.uuid4())
    fake_db[student_id] = student.dict()
    
    return StudentProfileResponse(
        student_id=student_id,
        status="success",
        message=f"Student {student.name} registered. Ready for diagnostic assessment."
    )
